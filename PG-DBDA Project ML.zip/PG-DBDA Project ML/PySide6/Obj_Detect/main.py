import sys
from PySide6.QtWidgets import *
from ui.splash_screen import SplashScreen



if __name__ == "__main__":
    app = QApplication(sys.argv)
    splash = SplashScreen()
    sys.exit(app.exec())
