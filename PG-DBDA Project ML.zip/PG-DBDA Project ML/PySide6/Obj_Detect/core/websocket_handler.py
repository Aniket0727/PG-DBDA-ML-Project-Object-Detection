from PySide6.QtWebSockets import QWebSocket
from PySide6.QtCore import QUrl
from PySide6.QtGui import QPixmap, Qt


class WebSocketHandler:
    def __init__(self, main_window):
        self.main_window = main_window
        self.ws = QWebSocket()
        self.ws.binaryMessageReceived.connect(self.on_binary_message)
        self.ws.errorOccurred.connect(self.on_error)

        self.ws.errorOccurred.connect(self.on_error)
        self.ws.connected.connect(self.on_connected)
        self.ws.disconnected.connect(self.on_disconnected)

        self.ws.connected.connect(self.on_connected)
        self.ws.disconnected.connect(self.on_disconnected)
        self.ws.errorOccurred.connect(self.on_error)

        # Set label to "Connecting..." immediately
        self.update_connection_status("Connecting...", "orange")

        # Open websocket connection
        self.ws.open(QUrl("ws://localhost:8000/ws/detect/"))


    def send_image_to_backend(self, image_path):
        self.ws.open(QUrl("ws://localhost:8000/ws/detect/"))

        def on_connected():
            with open(image_path, "rb") as f:
                image_bytes = f.read()
                self.ws.sendBinaryMessage(image_bytes)

        self.ws.connected.connect(on_connected)

    def on_binary_message(self, message):
        pixmap = QPixmap()
        if pixmap.loadFromData(message):
            self.main_window.ui.imgLeb.setPixmap(pixmap.scaled(
                self.main_window.ui.imgLeb.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            print("Could not load image from binary message.")

    def update_connection_status(self, text, color):
        try:
            label = self.main_window.ui.connectionStatusLabel
            label.setText(text)
            label.setStyleSheet(f"color: {color}; font-weight: bold;")
        except RuntimeError:
            # Label was deleted, ignore update
            pass

    def on_connected(self):
        self.update_connection_status("Connected", "green")

    def on_disconnected(self):
        self.update_connection_status("Disconnected", "red")

    def on_error(self, error):
        print(f"WebSocket error: {error}")
        self.update_connection_status(f"{error}", "red")
