from PySide6.QtWidgets import QMainWindow, QFileDialog, QLabel, QPushButton
from PySide6.QtCore import Qt, QSize, QFile, QUrl, QCoreApplication, QSize , QTimer
from PySide6.QtGui import QPixmap, QMovie , QRegion
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWebSockets import QWebSocket
from core.websocket_handler import WebSocketHandler
import json
import psutil


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loader = QUiLoader()
        ui_file = QFile("resources/main2.ui")
        ui_file.open(QFile.ReadOnly)
        self.ui = loader.load(ui_file, self)
        ui_file.close()

        self.setCentralWidget(self.ui)
        self.ws_handler = WebSocketHandler(self)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.ui.showFullScreen()

        self.ui.tabWid.tabBar().hide()
        self.ui.tabWid.setCurrentIndex(0)

        size = 70

        # Set size and movie
        self.movie = QMovie("resources/chatBot.gif")
        self.movie.setScaledSize(QSize(size, size))
        self.ui.gifLabel.setFixedSize(size, size)
        self.ui.gifLabel.setMovie(self.movie)
        self.movie.start()

        # Apply a circular mask for actual shape clipping
        region = QRegion(0, 0, size, size, QRegion.Ellipse)
        self.ui.gifLabel.setMask(region)

        # Optional: Apply border styling
        self.ui.gifLabel.setStyleSheet(f"""
            background-color: transparent;
        """)

        # Initialize counters
        self.last_sent = psutil.net_io_counters().bytes_sent
        self.last_recv = psutil.net_io_counters().bytes_recv


        self.network_timer = QTimer(self)
        self.network_timer.timeout.connect(self.update_network_speed)
        self.network_timer.start(1000)


        self.ui.minBtn.clicked.connect(self.showMinimized)
        self.ui.CloseButton.clicked.connect(QCoreApplication.quit)
        self.ui.chooseImg.clicked.connect(self.select_image)

        self.websocket = QWebSocket()
        self.websocket.connected.connect(self.on_connected)
        self.websocket.textMessageReceived.connect(self.on_message)
        self.websocket.open(QUrl("ws://localhost:8000/ws/qna/"))


        # Connect signals from your ui widgets
        self.ui.sendButton.clicked.connect(self.send_message)




        
    def on_connected(self):
        print("WebSocket connected!")

    def send_message(self):
        msg = self.ui.inputLineEdit.toPlainText().strip()
        if msg:
            data = json.dumps({"question": msg})  # ✅ use "question"
            self.websocket.sendTextMessage(data)
            self.ui.inputLineEdit.clear()

    def on_message(self, message):
        try:
            data = json.loads(message)
            reply = data.get("answer")  # ✅ get "answer"
            self.ui.responseLabel.setText(reply)
        except Exception as e:
            self.ui.responseLabel.setText(f"Error: {e}")

    def select_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Image", "", "Image Files (*.png *.jpg *.jpeg *.bmp);;All Files (*)"
        )
        if file_path:
            pixmap = QPixmap(file_path)
            self.ui.imgLeb.setPixmap(pixmap.scaled(self.ui.imgLeb.size(), Qt.KeepAspectRatio))
            self.ws_handler.send_image_to_backend(file_path)

    def update_network_speed(self):
        counters = psutil.net_io_counters()
        sent_now = counters.bytes_sent
        recv_now = counters.bytes_recv

        upload_speed = (sent_now - self.last_sent) / 1024  # KB/s
        download_speed = (recv_now - self.last_recv) / 1024

        self.last_sent = sent_now
        self.last_recv = recv_now

        # Update single label with both values
        self.ui.networkLabel.setText(
            f"⬇ {download_speed:.1f} KB/s   ⬆ {upload_speed:.1f} KB/s"
        )


