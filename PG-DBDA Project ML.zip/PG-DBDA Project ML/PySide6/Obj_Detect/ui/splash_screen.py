
from PySide6.QtCore import (QCoreApplication, QPropertyAnimation, QDate, QDateTime, QMetaObject, QObject, QPoint, QRect, QSize, QTime, QUrl, Qt, QEvent)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor, QFont, QFontDatabase, QIcon, QKeySequence,
                           QLinearGradient, QPalette, QPainter, QPixmap, QRadialGradient, QMovie)

from PySide6.QtWidgets import *
from PySide6.QtUiTools import QUiLoader
from PySide6.QtCore import (QFile ,QTimer)
from ui.main_window import MainWindow

from resources import  res

counter = 0
jumper = 20

class SplashScreen(QMainWindow):
    def __init__(self):
        super().__init__()
        loader = QUiLoader()
        ui_file = QFile("resources/splash_screen.ui")
        ui_file.open(QFile.ReadOnly)

        self.ui = loader.load(ui_file)
        self.ui.setWindowFlags(Qt.FramelessWindowHint)
        self.ui.setAttribute(Qt.WA_TranslucentBackground)
        ui_file.close()



        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setXOffset(0)
        shadow.setYOffset(0)
        shadow.setColor(QColor(0, 0, 0, 120))
        self.ui.circularBg.setGraphicsEffect(shadow)

        self.timer = QTimer()
        self.timer.timeout.connect(self.progress)
        self.timer.start(15)

        self.ui.show()

    def progress(self):
        global counter, jumper

        if counter > jumper:
            self.ui.labelPercentage.setText(f"<p><span style='font-size:68pt;'>{jumper}</span><span style='font-size:58pt; vertical-align:super;'>%</span></p>")
            jumper += 10

        if counter > 100:
            self.timer.stop()
            self.ui.close()  # Close splash screen widget
            self.main = MainWindow()
            self.main.show()
            return

        self.progressBarValue(counter)
        counter += 0.5

    def progressBarValue(self, value):
        progress = (100 - value) / 100.0
        stop_1 = str(progress - 0.001)
        stop_2 = str(progress)
        style = f"""
        QFrame {{
            border-radius: 150px;
            background-color: qconicalgradient(
                cx:0.5, cy:0.5, angle:90,
                stop:{stop_1} rgba(255, 0, 127, 0),
                stop:{stop_2} rgba(217, 59, 82, 1));
        }}
        """
        self.ui.circularProgress.setStyleSheet(style)
