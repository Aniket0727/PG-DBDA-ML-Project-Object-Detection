# from ultralytics import YOLO
# import os
# from IPython.display import display, Image
# from IPython import display
#
# model = YOLO('yolov8x.pt')
#
# results = model.train(
#     task='detect',
#     data='custom.yaml',
#     epochs=100,
#     imgsz=640,
#     batch=16,
#     device=0
# )
#
# print("Training complete!")
# print(f"Best weights saved at: {results.best}")
#

from ultralytics import YOLO  # or whatever imports you use

def train_model():
    model = YOLO("yolov8n.yaml")  # or the correct model path
    results = model.train(
        task='detect',
        data='custom.yaml',
        device=0,   # or '0' if you have a GPU
        epochs=100,
        imgsz=640,
        batch=4
    )
    print("Training complete!")
    print(f"Best weights saved at: {results.best}")

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()  # Optional but good practice on Windows
    train_model()

