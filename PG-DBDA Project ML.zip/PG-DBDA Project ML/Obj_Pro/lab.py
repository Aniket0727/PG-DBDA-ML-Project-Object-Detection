from ultralytics import YOLO
import os

model = YOLO('yolov8x.pt') 

image_dir = '/home/omkarmhetre/Desktop/base/Obj_Pro/train'
output_dir = '/home/omkarmhetre/Desktop/base/Obj_Pro/label_train'

os.makedirs(output_dir, exist_ok=True)

for img_file in os.listdir(image_dir):
    if img_file.endswith(('.jpg', '.png', '.jpeg')):
        results = model.predict(source=os.path.join(image_dir, img_file), save=False)
        results[0].save_txt(os.path.join(output_dir, img_file.replace('.jpg', '.txt')))
print("Task Done")